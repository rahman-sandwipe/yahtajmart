
<?php $__env->startSection('page_title'); ?>
    <title>Settings</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboard_layouts'); ?>
<div id="main-content" class="profilepage_1">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-5 col-md-8 col-sm-12">
                    <h2>
                        <ul class="breadcrumb">
                            <li><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item active">Settings</li>
                        </ul>
                    </h2>
                </div>
            </div>
        </div>
        <div class="card">
            <div>
                <?php if(session()->has('success')): ?>
                    <p class="bg-success">
                        <?php echo e(session()->get('success')); ?>

                    </p>
                <?php endif; ?>
                
                <?php if($errors->any()): ?>
                    <ul class="bg-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="body">
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#Settings">Settings</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#socials">Socials Link</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#supportCenter">Support Center</a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content">

                        
                        <div class="tab-pane active" id="Settings">
                            <?php echo $__env->make('backends.pages.settings.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        
                        <div class="tab-pane" id="socials">
                            <?php echo $__env->make('backends.pages.settings.socials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        
                        
                        
                        <div class="tab-pane" id="supportCenter">
                            <?php echo $__env->make('backends.pages.settings.support-center', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backends.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel_11\yahtaj\resources\views/backends/pages/settings/partialssettings.blade.php ENDPATH**/ ?>