<div id="left-sidebar" class="sidebar">
    <div class="sidebar-scroll">
        
        <!-- Nav tabs -->
        <ul class="nav nav-tabs mt-2">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#menu">
                    <i class="fa fa-bars"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#Chat">
                    <i class="icon-book-open"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#setting">
                    <i class="icon-settings"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#profile">
                    <i class="icon-user"></i>
                </a>
            </li>
        </ul>
        <!-- Tab panes -->
        <div class="tab-content p-l-0 p-r-0">
            <div class="tab-pane active" id="menu">
                <nav id="left-sidebar-nav" class="sidebar-nav">
                    <ul id="main-menu" class="metismenu">
                        <li class="<?php echo e(Request::routeIs('dashboard') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route(auth()->user()->user_type)); ?>">
                                <i class="fa fa-home"></i> <span>Dashboard</span>
                            </a>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="fa fa-shopping-cart"></i> <span>Products</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('product.index')); ?>">Products</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('product.create')); ?>">New Product</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="fa fa-newspaper-o"></i> <span>Blog</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('blog.index')); ?>">All Post</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('blog.create')); ?>">New Post</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="fa fa-image"></i> <span>Gallary</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('photo.index')); ?>">Images</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('photo.create')); ?>">Add Image</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="icon-camera"></i> <span>Videos</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('video.index')); ?>">Videos</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('video.create')); ?>">New Video</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="icon-star"></i> <span>FeedBack</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('feedback.index')); ?>">FeedBack</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('feedback.create')); ?>">New New</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="icon-grid"></i> <span>Brands</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('brand.index')); ?>">Brands</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('brand.create')); ?>">Add New</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="icon-grid"></i> <span>Category</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('category.index')); ?>">Category</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('category.create')); ?>">Add New</a>
                                </li>
                            </ul>
                        </li>
                        
                        
                        <li>
                            <a href="javascript:void(0);" class="has-arrow">
                                <i class="icon-grid"></i> <span>Banners</span>
                            </a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('banner.index')); ?>">Banners</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('banner.create')); ?>">Add New</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li class="<?php echo e(Request::routeIs('users') ? 'active' : ''); ?>">
                            <a href="JavaScript:void(0);" class="has-arrow">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                            <ul>
                                <li class="<?php echo e(Request::routeIs('users') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('users')); ?>">Users</a>
                                </li>
                                <li class="<?php echo e(Request::routeIs('newuser') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('newuser')); ?>">Add New</a>
                                </li>
                            </ul>
                        </li>

                        
                        <li class="<?php echo e(Request::routeIs('settings') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('settings')); ?>">
                                <i class="fa fa-cog"></i><span>Settings</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="tab-pane p-l-15 p-r-15" id="Chat">
                <form>
                    <div class="input-group m-b-20">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="icon-magnifier"></i></span>
                        </div>
                        <input type="text" class="form-control" placeholder="Search...">
                    </div>
                </form>
                <ul class="right_chat list-unstyled">
                    
                <hr>
                <h6>General Settings</h6>
                <ul class="setting-list list-unstyled">
                    <li>
                        <label class="fancy-checkbox">
                        <input type="checkbox" name="checkbox">
                        <span>Report Panel Usag</span>
                        </label>
                    </li>
                    <li>
                        <label class="fancy-checkbox">
                        <input type="checkbox" name="checkbox" checked>
                        <span>Email Redirect</span>
                        </label>
                    </li>
                    <li>
                        <label class="fancy-checkbox">
                        <input type="checkbox" name="checkbox" checked>
                        <span>Notifications</span>
                        </label>                      
                    </li>
                    <li>
                        <label class="fancy-checkbox">
                        <input type="checkbox" name="checkbox">
                        <span>Auto Updates</span>
                        </label>
                    </li>
                    <li>
                        <label class="fancy-checkbox">
                        <input type="checkbox" name="checkbox">
                        <span>Offline</span>
                        </label>
                    </li>
                    <li>
                        <label class="fancy-checkbox">
                        <input type="checkbox" name="checkbox">
                        <span>Location Permission</span>
                        </label>
                    </li>
                </ul>
            </div>


            <!-- Page Settings --> 
            <div class="tab-pane p-l-15 p-r-15" id="setting">
                <nav id="" class="sidebar-nav">
                    <ul id="main-menu" class="metismenu">
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-home"></i> <span>Home</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-address-card"></i> <span>About</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-line-chart"></i> <span>Projects</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-wrench"></i> <span>Servece</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-users"></i> <span>Teams</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-video-camera"></i> <span>Videos</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="fa fa-newspaper-o"></i> <span>Blogs</span></a>
                        </li>
                        <li>
                            <a href="javascript:void(0);" class="has-arrow"><i class="icon-grid"></i> <span>Contacts</span></a>
                        </li>
                    </ul>
                </nav>
            </div>

            <!-- User Profile -->
            <div class="tab-pane p-l-15 p-r-15" id="profile">
                <div class="user-account">
                    <img src="<?php echo e(asset('uploads/users/default_image.png')); ?>" class="rounded-circle w-100" alt="User Profile Picture">
                    <div>
                        <span>Welcome,</span>
                        <a href="javascript:void(0);" class="user-name">
                            <strong class="text-center"><?php echo e(auth()->user()->name); ?></strong>
                            <p class="text-center"><?php echo e(auth()->user()->email); ?></p>
                        </a>
                    </div>
                    <hr>
                    <ul class="row list-unstyled">
                        <li class="col-4">
                            <small>Sales</small>
                            <h6>456</h6>
                        </li>
                        <li class="col-4">
                            <small>Order</small>
                            <h6>1350</h6>
                        </li>
                        <li class="col-4">
                            <small>Revenue</small>
                            <h6>$2.13B</h6>
                        </li>
                    </ul>
                </div>
                <ul class="dropdown-menu dropdown-menu-right account">
                    <li><a href="page-profile2.html"><i class="icon-user"></i>My Profile</a></li>
                    <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>Messages</a></li>
                    <li><a href="javascript:void(0);"><i class="icon-settings"></i>Settings</a></li>
                    <li class="divider"></li>
                    <li><a href="page-login.html"><i class="icon-power"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\laravel_11\yahtaj\resources\views/backends/inc/sidebar.blade.php ENDPATH**/ ?>