
<!-- VENDOR CSS -->
<link rel="stylesheet" href="<?php echo e(asset('backends/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backends/vendor/font-awesome/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backends/vendor/jvectormap/jquery-jvectormap-2.0.3.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('backends/vendor/morrisjs/morris.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('backends/vendor/summernote/dist/summernote.css')); ?>"/>
<!-- MAIN CSS -->
<link rel="stylesheet" href="<?php echo e(asset('backends/css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backends/css/color_skins.css')); ?>"><?php /**PATH E:\laravel_11\yahtaj\resources\views/backends/inc/styles.blade.php ENDPATH**/ ?>