<div class="row clearfix">
    <div class="col-lg-6 col-md-12">
        <div class="body">
            <h6>Add Your Social Media Link</h6>
            <form action="<?php echo e(route('social.insert')); ?>" method="POST"><?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nameInput">Media Name</label>
                    <input type="text" name="name" id="nameInput" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="iconInput">Media Icon</label>
                    <input type="text" name="icon" id="iconInput" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="linkInput">Media Link</label>
                    <input type="text" name="link" id="linkInput" class="form-control" required>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-block">INSERT</button>
                </div>
            </form>
        </div>
    </div>
    <div class="col-lg-6 col-md-12">
        <div class="body">
            <h6>Connected Social Media</h6>
            <ul class="list-unstyled list-connected-app">
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="connected-app">
                        <i class="app-icon <?php echo e($social->icon); ?>"></i>
                        <div class="connection-info">
                            <h3 class="app-title"><?php echo e($social->name); ?></h3>
                            <span class="actions">
                                <a href="<?php echo e($social->link); ?>" class="badge badge-info"><i class="fa fa-link"></i>Hit Link</a> 
                                <button href="type" value="$social->id" data-toggle="modal" class="badge badge-danger editbtn" data-target="#defaultModal">
                                    <i class="fa fa-edit"></i><span>Edit Media</span>
                                </button>   
                            </span>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>

<!-- Modal Dialogs ========= --> 
<!-- Default Size -->
<div class="modal fade" id="defaultModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="card">
                <div class="card-body">
                    
                    
                    <form action="" method="POST"><?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="nameInput">Media Name</label>
                            <input type="text" name="name" id="nameInput" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="iconInput">Media Icon</label>
                            <input type="text" name="icon" id="iconInput" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="linkInput">Media Link</label>
                            <input type="text" name="link" id="linkInput" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success btn-block">INSERT</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\laravel_11\yahtaj\resources\views/backends/pages/settings/socials.blade.php ENDPATH**/ ?>