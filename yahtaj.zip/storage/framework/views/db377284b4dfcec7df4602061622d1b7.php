<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30">
            <img src="<?php echo e(asset($config->web_logo)); ?>" width="300" height="60" alt="<?php echo e($config->web_name); ?>">
        </div>
        <p>Please wait...</p>
    </div>
</div><?php /**PATH E:\laravel_11\yahtaj\resources\views/backends/inc/preloader.blade.php ENDPATH**/ ?>