

<script src="<?php echo e(asset('backends/bundles/libscripts.bundle.js')); ?>"></script>    
<script src="<?php echo e(asset('backends/bundles/vendorscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backends/bundles/jvectormap.bundle.js')); ?>"></script> <!-- JVectorMap Plugin Js -->
<script src="<?php echo e(asset('backends/bundles/morrisscripts.bundle.js')); ?>"></script><!-- Morris Plugin Js -->
<script src="<?php echo e(asset('backends/bundles/knob.bundle.js')); ?>"></script> <!-- Jquery Knob-->
<script src="<?php echo e(asset('backends/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backends/js/index4.js')); ?>"></script>


<script src="<?php echo e(asset('backends/vendor/summernote/dist/summernote.js')); ?>"></script><?php /**PATH E:\laravel_11\yahtaj\resources\views/backends/inc/scripts.blade.php ENDPATH**/ ?>