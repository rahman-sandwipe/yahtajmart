<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/',     [HomeController::class, 'home'])->name(('home'));
Route::get('/shop', [HomeController::class, 'shop'])->name(('shop'));
Route::get('/category/{Category:Slug}', [HomeController::class, 'category'])->name('category');
Route::get('/product-details/{Product:Slug}',  [HomeController::class, 'product_details'])->name('product_details');


require __DIR__.'/auth.php';
