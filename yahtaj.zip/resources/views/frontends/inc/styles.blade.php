<link rel="stylesheet" href="{{ asset('frontends/css/plugins/animate.min.css') }}" />
<link rel="stylesheet" href="{{ asset('frontends/css/main5103.css?v=6.0') }}" />