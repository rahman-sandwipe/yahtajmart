@extends('frontends.master')
@section('page_title')
   <title>YAHTAJ MART - Multipurpose eCommerce Flatform</title>
@endsection
@section('front_layouts')
<section class="home-slider position-relative mb-30">
    <div class="container">
        @if (count($banners)>0)
        <div class="home-slide-cover mt-30">
            <div class="hero-slider-1 style-4 dot-style-1 dot-style-1-position-1">
                @foreach ($banners as $banner)
                <div class="single-hero-slider single-animation-wrap" style="background-image: url({{ ($banner->thumb) }})">
                    <div class="slider-content">
                        <h1 class="display-2 mb-40">
                            Don’t miss amazing<br />
                            grocery deals
                        </h1>
                        <p class="mb-65">Sign up for the daily newsletter</p>
                        <form class="form-subcriber d-flex">
                            <input type="email" placeholder="Your emaill address" />
                            <button class="btn" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="slider-arrow hero-slider-1-arrow"></div>
        </div>
        @else
        <div class="card">
            <div class="body">
                <h3 class="text-center text-danger"></h3>
            </div>
        </div>
        @endif
    </div>
</section>
<!--End hero slider-->
<section class="popular-categories section-padding">
    <div class="container">
        <div class="section-title d-flex justify-content-center">
            <div class="title">
                <h3>Featured Categories</h3>
            </div>
        </div>
        <div class="carausel-10-columns-cover position-relative">
            <div class="carausel-10-columns" id="carausel-10-columns">
                @foreach ($categories as $category)
                <div class="card-2 bg-9 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                   <figure class="img-hover-scale overflow-hidden">
                       <a href="{{ route('category',$category->slug) }}">
                            <img src="{{ asset($category->thumb) }}" />
                        </a>
                    </figure>
                    <h6><a href="{{ route('category',$category->slug) }}">{{ $category->name }}</a></h6>
                    {{-- <span>26 items</span> --}}
                </div>
                @endforeach
           </div>
       </div>
   </div>
</section>

<section class="product-tabs section-padding position-relative">
    <div class="container">
        <div class="section-title d-flex justify-content-center">
            <h3>Latest Products</h3>
        </div>
        <!--End nav-tabs-->
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="tab-one" role="tabpanel" aria-labelledby="tab-one">
                <div class="row product-grid-4">
                    @foreach ($products as $product)
                    <div class="col-lg-1-5 col-md-4 col-12 col-sm-6">
                        <div class="product-cart-wrap mb-30 wow animate__animated animate__fadeIn" data-wow-delay=".1s">
                            <div class="product-img-action-wrap">
                                <div class="product-img product-img-zoom">
                                    <a href='shop-product-right.html'>
                                        <img class="default-img" src="{{ asset($product->thumb) }}" alt="" />
                                        <img class="hover-img" src="{{ asset($product->thumb) }}" alt="" />
                                    </a>
                                </div>
                                <div class="product-action-1">
                                    <a aria-label="Quick view" class="action-btn" data-bs-toggle="modal" data-bs-target="#quickViewModal"><i class="fi-rs-eye"></i></a>
                                </div>
                                <div class="product-badges product-badges-position product-badges-mrg">
                                    <span class="hot">Hot</span>
                                </div>
                            </div>
                            <div class="product-content-wrap">
                                <div class="product-category">
                                    <a href='shop-grid-right.html'>
                                        <img src="{{ @$product->brand->thumb }}" width="60">
                                    </a>
                                </div>
                                <div class="product-category">
                                    <a href='shop-grid-right.html'>{{ @$product->category->name }}</a>
                                </div>
                                <h2><a href='shop-product-right.html'>{{ $product->title }}</a></h2>
                                {{-- <div class="product-rate-cover">
                                    <div class="product-rate d-inline-block">
                                        <div class="product-rating" style="width: 90%"></div>
                                    </div>
                                    <span class="font-small ml-5 text-muted"> (4.0)</span>
                                </div> --}}
                                <div>
                                    <span class="font-small text-muted">
                                        <span>Sold By:</span>
                                        <a href='vendor-details-1.html'>{{ $product->user->name }}</a>
                                    </span>
                                </div>
                                <div class="product-card-bottom">
                                    <div class="product-price">
                                        <span>৳{{ $product->offer_price }}</span>
                                        <span class="old-price">৳{{ $product->regular_price }}</span>
                                    </div>
                                    <div class="add-cart">
                                        <a class='add' href='shop-cart.html'><i class="fi-rs-shopping-cart mr-5"></i>Add </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <!--End product-grid-4-->
                <div class="d-flex justify-content-center">

                    {{ $products->links() }}
        
                </div>
            </div>
            <!--En tab one-->
        </div>
        <!--End tab-content-->
    </div>
</section>

<div class="page-content mb-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="shop-product-fillter mb-50">
                    <div class="totall-product">
                        <h2>Recent Articles</h2>
                    </div>
                    <div class="sort-by-product-area">
                        <div class="sort-by-cover mr-10">
                            <div class="sort-by-product-wrap">
                                <div class="sort-by">
                                    <span><i class="fi-rs-apps"></i>Show More</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="loop-grid">
                    <div class="row">
                        @foreach ($blogs as $article)
                        <article class="col-xl-3 col-lg-4 col-md-6 text-center hover-up mb-30 animated">
                            <div class="post-thumb">
                                <a href='blog-post-right.html'>
                                    <img class="border-radius-15" src="{{ asset($article->thumb) }}" />
                                </a>
                                <div class="entry-meta">
                                    <a class='entry-meta meta-2' href='blog-category-grid.html'><i class="fi-rs-heart"></i></a>
                                </div>
                            </div>
                            <div class="entry-content-2">
                                <h6 class="mb-10 font-sm">
                                    <a class='entry-meta text-muted' href='blog-category-grid.html'>Side Dish</a>
                                </h6>
                                <h4 class="post-title mb-15">
                                    <a href='blog-post-right.html'>{{ $article->headline }}</a>
                                </h4>
                                <div class="entry-meta font-xs color-grey mt-10 pb-10">
                                    <div>
                                        <span class="post-on mr-10">{{ $article->created_at->format('d M Y') }}</span>
                                        <span class="hit-count has-dot mr-10">{{ $article->count }} Views</span>
                                        {{-- <span class="hit-count has-dot">4 mins read</span> --}}
                                    </div>
                                </div>
                            </div>
                        </article>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection