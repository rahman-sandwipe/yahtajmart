@php
   $category=App\Models\Category::where(['status'=>'public'])->latest()->get();
   $config=App\Models\Settings::latest()->first();
   $supports=App\Models\SupportCenter::latest()->first();
@endphp
<!DOCTYPE html>
   <html lang="en">
   <head>
        <meta charset="utf-8" />
        @yield('page_title')
        <meta http-equiv="x-ua-compatible" content="ie=edge" />
        <meta name="description" content="" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta property="og:title" content="" />
        <meta property="og:type" content="" />
        <meta property="og:url" content="" />
        <meta property="og:image" content="" />
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('frontends/imgs/theme/favicon.svg') }}" />
        <!-- Template CSS -->
        @include('frontends.inc.styles')
   </head>

   <body>
        @include('frontends.inc.header')
        <!--End header-->
        
        <main class="main">
        @yield('front_layouts')
        </main>
    
        @include('frontends.inc.footer')
    
        <!-- Preloader Start -->
        {{-- @include('frontends.inc.preloader') --}}
        <!-- Vendor JS--> <!-- Template  JS -->
        @include('frontends.inc.scripts')
</body>
</html>