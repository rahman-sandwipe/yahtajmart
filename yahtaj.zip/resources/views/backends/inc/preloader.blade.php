<div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30">
            <img src="{{ asset($config->web_logo) }}" width="300" height="60" alt="{{ $config->web_name }}">
        </div>
        <p>Please wait...</p>
    </div>
</div>