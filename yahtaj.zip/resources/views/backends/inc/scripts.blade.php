

<script src="{{ asset('backends/bundles/libscripts.bundle.js') }}"></script>    
<script src="{{ asset('backends/bundles/vendorscripts.bundle.js') }}"></script>
<script src="{{ asset('backends/bundles/jvectormap.bundle.js') }}"></script> <!-- JVectorMap Plugin Js -->
<script src="{{ asset('backends/bundles/morrisscripts.bundle.js') }}"></script><!-- Morris Plugin Js -->
<script src="{{ asset('backends/bundles/knob.bundle.js') }}"></script> <!-- Jquery Knob-->
<script src="{{ asset('backends/bundles/mainscripts.bundle.js') }}"></script>
<script src="{{ asset('backends/js/index4.js') }}"></script>
{{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> --}}
{{-- Vendor --}}
<script src="{{ asset('backends/vendor/summernote/dist/summernote.js') }}"></script>