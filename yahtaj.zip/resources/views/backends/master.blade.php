@php
   $socials = App\Models\Social::orderBy('id','DESC')->get();
   $config  = App\Models\Settings::where('id','1')->first();
@endphp
<!doctype html>
<html lang="en">
    <head>
		@yield('page_title')
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<meta name="description" content="Photographer Portfolio Admin Template | Bootstrap 4.1.1">
		<meta name="author" content="MoreXhub Tech LMT, design by: morexhub.com">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		
		<!-- CSS File -->
		@include('backends.inc.styles')
		<style>
			.preview-images-zone {
				width: 100%;
				border: 1px solid #ddd;
				min-height: 72px;
				border-radius: 5px;
				padding: 1px;
				display: flex;
				justify-content: center;
				align-items: center;
				flex-wrap: wrap;
				box-sizing: border-box;
			}
			.preview-image {
				width: 100px;
				height: 50px;
				margin: 10px;
				overflow: hidden;
				position: relative;
			}
			.preview-image img {
				width: 100%;
				height: 100%;
				object-fit: cover;
			}
		</style>
	</head>
	<body class="theme-cyan">
		<!-- Page Loader -->
		@include('backends.inc.preloader')

        
		<!-- Overlay For Sidebars -->
		<div id="wrapper">
            @guest
            @else
		
            <!--  Navbar  -->
            @include('backends.inc.navbar')
            
            
            <!--  Navbar  -->
            @include('backends.inc.sidebar')
			
            @endguest
            @yield('dashboard_layouts')
			@yield('page_scripts')
		</div>
		<!-- Javascript -->
		@include('backends.inc.scripts')
		@yield('scripts')
	</body>
</html>